export default function Playlist() {
  return (
    <div>Playlist</div>
  )
}
