import "./About.css";

export default function About() {
  return (
    <div className="about-container" name="about">
      <h1 className="about-heading">About</h1>
      <div className="about-description">
        <h2>Lorem ipsum dolor sit amet consectetur adipisicing elit. Veritatis a tempore magnam illum at! Ab, fugiat. Culpa dolorum laborum veritatis, non assumenda soluta maxime minus rem rerum quibusdam magni aperiam.</h2>
        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Eligendi quibusdam quis fugit nostrum voluptate deleniti ducimus odio debitis, animi dolor dolorem perferendis esse, repellat id accusantium vel aliquam facilis mollitia!</p>
      </div>
    </div>
  )
}
